package com.lcm.documentaccess.templates;
import com.appian.connectedsystems.simplified.sdk.SimpleConnectedSystemTemplate;
import com.appian.connectedsystems.simplified.sdk.configuration.SimpleConfiguration;
import com.appian.connectedsystems.templateframework.sdk.ExecutionContext;
import com.appian.connectedsystems.templateframework.sdk.TemplateId;
@TemplateId(name="DocumentAccessCST")
public class DocumentAccessCST extends SimpleConnectedSystemTemplate {
       public static final String UPLOAD_DOC_AS_PROP = "uploadImageAs";

    @Override
    protected SimpleConfiguration getConfiguration(
            SimpleConfiguration simpleConfiguration, ExecutionContext executionContext) {
        return simpleConfiguration.setProperties(

                textProperty(UPLOAD_DOC_AS_PROP)
                        .label("Access Document as User")
                        .instructionText("Document get from the appian will be shown accessed by this user")
                        .isRequired(true)
                        .build());
    }
}
